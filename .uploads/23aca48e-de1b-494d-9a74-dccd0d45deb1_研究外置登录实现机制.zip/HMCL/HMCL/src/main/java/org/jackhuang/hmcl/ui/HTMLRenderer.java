/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2024 huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui;

import javafx.beans.InvalidationListener;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Separator;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import org.jackhuang.hmcl.util.Lang;
import org.jackhuang.hmcl.util.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;

import java.net.URI;
import java.util.*;
import java.util.function.Consumer;

import static org.jackhuang.hmcl.setting.SettingsManager.settings;
import static org.jackhuang.hmcl.util.logging.Logger.LOG;

/**
 * @author Glavo
 */
public final class HTMLRenderer {

    private static URI resolveLink(Node linkNode) {
        String href = linkNode.absUrl("href");
        if (href.isEmpty())
            return null;

        try {
            return new URI(href);
        } catch (Throwable e) {
            return null;
        }
    }

    /// @see org.jsoup.internal.StringUtil#isWhitespace(int)
    public static boolean isWhitespace(int c) {
        return c == ' ' || c == '\t' || c == '\n' || c == '\f' || c == '\r';
    }

    /// @see org.jsoup.internal.StringUtil#isInvisibleChar(int)
    public static boolean isInvisibleChar(int c) {
        return c == 8203 || c == 173; // zero width sp, soft hyphen
        // previously also included zw non join, zw join - but removing those breaks semantic meaning of text
    }

    /// @see org.jsoup.internal.StringUtil#normaliseWhitespace(String)
    /// @see org.jsoup.internal.StringUtil#isActuallyWhitespace(int)
    public static String normaliseWhitespace(String str) {
        var accum = new StringBuilder();
        boolean lastWasWhite = false;
        int len = str.length();
        int i = 0;
        while (i < len) {
            int c = str.codePointAt(i);
            if (isWhitespace(c)) { // Ignore &nbsp;
                if (lastWasWhite) {
                    i += Character.charCount(c);
                    continue;
                }
                accum.append(' ');
                lastWasWhite = true;
            } else if (!isInvisibleChar(c)) {
                accum.appendCodePoint(c);
                lastWasWhite = false;
            }
            i += Character.charCount(c);
        }
        return accum.toString();
    }

    private final List<javafx.scene.Node> children = new ArrayList<>();
    private final List<Node> stack = new ArrayList<>();

    private boolean bold;
    private boolean italic;
    private boolean underline;
    private boolean strike;
    private boolean highlight;
    private boolean preformatted;
    private boolean code;
    private int listDepth;
    private String headerLevel;
    private Node hyperlink;
    private String fxStyle;

    private final Consumer<URI> onClickHyperlink;

    private boolean rendered;

    public HTMLRenderer(Consumer<URI> onClickHyperlink) {
        this.onClickHyperlink = onClickHyperlink;
    }

    private void updateStyle() {
        bold = false;
        italic = false;
        underline = false;
        strike = false;
        highlight = false;
        preformatted = false;
        code = false;
        listDepth = 0;
        headerLevel = null;
        hyperlink = null;
        fxStyle = null;

        var declarations = new SimpleCssDeclarations();
        for (Node node : stack) {
            String nodeName = node.nodeName();
            switch (nodeName) {
                case "b", "strong" -> bold = true;
                case "i", "em" -> italic = true;
                case "ins" -> underline = true;
                case "del" -> strike = true;
                case "mark" -> highlight = true;
                case "pre" -> preformatted = true;
                case "code" -> code = true;
                case "a" -> hyperlink = node;
                case "h1", "h2", "h3", "h4", "h5", "h6" -> headerLevel = nodeName;
                case "li" -> listDepth++;
            }

            declarations.add(node.attr("style"));
        }
        fxStyle = declarations.asString();
    }

    private void pushNode(Node node) {
        stack.add(node);
        updateStyle();
    }

    private void popNode() {
        stack.remove(stack.size() - 1);
        updateStyle();
    }

    private void applyStyle(Text text) {
        if (code) {
            text.getStyleClass().add("html-code");
            text.setStyle("-fx-font-family: \"%s\";".formatted(Objects.requireNonNullElse(settings().logFontFamilyProperty().get(), FXUtils.DEFAULT_MONOSPACE_FONT)));
            return;
        }

        var styleBuilder = new StringBuilder();

        if (hyperlink != null) {
            URI target = resolveLink(hyperlink);
            if (target != null) {
                FXUtils.onClicked(text, () -> onClickHyperlink.accept(target));
                text.setCursor(Cursor.HAND);
            }
            text.getStyleClass().add("html-hyperlink");
        }

        if (hyperlink != null || underline)
            text.setUnderline(true);

        if (strike)
            text.setStrikethrough(true);

        if (bold || highlight)
            text.getStyleClass().add("html-bold");

        if (italic)
            text.getStyleClass().add("html-italic");

        if (headerLevel != null)
            text.getStyleClass().add("html-" + headerLevel);

        if (fxStyle != null)
            styleBuilder.append(fxStyle);
        text.setStyle(styleBuilder.toString());
    }

    private void appendText(String text) {
        Text textNode = new Text(text);
        applyStyle(textNode);
        if (code) {
            var codeFlow = new CodeFlow(textNode);
            codeFlow.getStyleClass().add("html-code-block");
            children.add(codeFlow);
        } else {
            children.add(textNode);
        }
    }

    private void appendAutoLineBreak(String text) {
        AutoLineBreak textNode = new AutoLineBreak(text);
        applyStyle(textNode);
        children.add(textNode);
    }

    private void appendImage(Node node) {
        String src = node.absUrl("src");
        String alt = node.attr("alt");

        if (StringUtils.isNotBlank(src)) {
            String widthAttr = node.attr("width");
            String heightAttr = node.attr("height");

            int width = 0;
            int height = 0;

            if (!widthAttr.isEmpty() && !heightAttr.isEmpty()) {
                try {
                    width = (int) Double.parseDouble(widthAttr);
                    height = (int) Double.parseDouble(heightAttr);
                } catch (NumberFormatException ignored) {
                }

                if (width <= 0 || height <= 0) {
                    width = 0;
                    height = 0;
                }
            }

            try {
                ImageView imageView = new ImageView();

                imageView.imageProperty().bind(FXUtils.newRemoteImage(src, width, height, true, true));
                imageView.setPreserveRatio(true);

                ImagePane imagePane = new ImagePane(imageView, alt);

                if (hyperlink != null) {
                    URI target = resolveLink(hyperlink);
                    if (target != null) {
                        FXUtils.onClicked(imagePane, () -> onClickHyperlink.accept(target));
                        imagePane.setCursor(Cursor.HAND);
                    }
                }

                children.add(imagePane);
                return;
            } catch (Throwable e) {
                LOG.warning("Failed to load image: " + src, e);
            }
        }

        if (!alt.isEmpty())
            appendText(alt);
    }

    private void appendTable(Node table) {
        var childElements = ((Element) table).children();
        List<Element> captions = new ArrayList<>();

        List<Element> head = new ArrayList<>();
        List<List<Element>> body = new ArrayList<>();
        List<Element> foot = new ArrayList<>();

        boolean hasHead = false;
        boolean hasBody = childElements.stream().map(Element::nodeName).anyMatch("tbody"::equals);
        boolean hasFoot = false;
        int columnCount = 0;
        for (Element child : childElements) {
            switch (child.nodeName()) {
                case "caption" -> captions.add(child);
                case "thead" -> {
                    if (hasHead) continue;
                    hasHead = true;
                    for (Element e : child.children()) {
                        if (e.nameIs("tr")) {
                            head.clear();
                            head.addAll(
                                    e.children().stream()
                                            .filter(n -> n.nameIs("th") || n.nameIs("td"))
                                            .toList()
                            );
                            break;
                        }
                        if (e.nameIs("th") || e.nameIs("td")) {
                            head.add(e);
                        }
                    }
                    columnCount = Math.max(columnCount, head.size());
                }
                case "tbody" -> {
                    var rows = child.children().stream()
                            .filter(e -> e.nameIs("tr"))
                            .map(e ->
                                    e.children().stream().filter(n -> n.nameIs("th") || n.nameIs("td")).toList())
                            .filter(row -> !row.isEmpty())
                            .toList();
                    body.addAll(rows);
                    columnCount = Math.max(columnCount, rows.stream().mapToInt(List::size).max().orElse(0));
                }
                case "tfoot" -> {
                    if (hasFoot) continue;
                    hasFoot = true;
                    for (Element e : child.children()) {
                        if (e.nameIs("tr")) {
                            foot.clear();
                            foot.addAll(
                                    e.children().stream()
                                            .filter(n -> n.nameIs("th") || n.nameIs("td"))
                                            .toList()
                            );
                            break;
                        }
                        if (e.nameIs("th") || e.nameIs("td")) {
                            foot.add(e);
                        }
                    }
                    columnCount = Math.max(columnCount, foot.size());
                }
                case "tr" -> {
                    if (hasBody) continue;
                    List<Element> row = child.children().stream()
                            .filter(n -> n.nameIs("th") || n.nameIs("td"))
                            .toList();
                    if (!row.isEmpty()) {
                        body.add(row);
                        columnCount = Math.max(columnCount, row.size());
                    }
                }
            }
        }

        head = Lang.copyWithSize(head, columnCount, null);

        List<List<Element>> rows = new ArrayList<>(hasFoot ? body.size() + 1 : body.size());
        for (List<Element> row : body)
            rows.add(Lang.copyWithSize(row, columnCount, null));
        if (hasFoot)
            rows.add(Lang.copyWithSize(foot, columnCount, null));

        TableView<List<Element>> tableView = FXUtils.newAutoHeightTable(FXCollections.observableList(rows));
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        for (int i = 0; i < columnCount; i++) {
            int finalI = i;
            TableColumn<List<Element>, Element> c = new TableColumn<>();
            Element e = head.get(i);
            if (e != null) {
                var box = new VBox(new HTMLRenderer(onClickHyperlink).appendNode(e).mergeLineBreaks().render());
                box.setAlignment(Pos.CENTER_LEFT);
                c.setGraphic(box);
            }
            c.setCellFactory(param -> new TableCell<>() {
                @Override
                protected void updateItem(Element item, boolean empty) {
                    if (item == getItem()) return;
                    super.updateItem(item, empty);
                    if (item == null) {
                        setGraphic(null);
                    } else {
                        setGraphic(new Pane(new HTMLRenderer(onClickHyperlink).appendNode(item).mergeLineBreaks().render()));
                    }
                }
            });
            c.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(finalI)));
            tableView.getColumns().add(c);
        }

        for (Element caption : captions) {
            appendAutoLineBreak("\n\n");
            appendChildren(caption);
            appendAutoLineBreak("\n");
        }

        children.add(tableView);
    }

    private void appendOrderedList(Node node) {
        pushNode(node);
        int ordinal = StringUtils.toInt(node.attr("start")).orElse(1);
        for (Node childNode : node.childNodes()) {
            if (childNode.nameIs("li")) {
                ordinal = StringUtils.toInt(childNode.attr("value")).orElse(ordinal);
                appendAutoLineBreak("\n");
                appendText(" " + "  ".repeat(listDepth) + ordinal++ + ". ");
                appendChildren(childNode);
                continue;
            }
            appendNode(childNode);
        }
        popNode();
    }

    private void appendChildren(Node node) {
        if (node.childNodeSize() > 0) {
            if (node.nameIs("table")) {
                appendTable(node);
            } else if (node.nameIs("ol")) {
                appendOrderedList(node);
            } else {
                pushNode(node);
                for (Node childNode : node.childNodes()) {
                    appendNode(childNode);
                }
                popNode();
            }
        }
    }

    public HTMLRenderer appendNode(Node node) {
        if (node instanceof TextNode n) {
            appendText(preformatted ? n.getWholeText() : normaliseWhitespace(n.getWholeText()));
        }

        String name = node.nodeName();
        switch (name) {
            case "img" -> {
                if (!children.isEmpty())
                    appendAutoLineBreak("\n");
                appendImage(node);
                appendAutoLineBreak("\n");
            }
            case "li" -> {
                appendAutoLineBreak("\n");
                appendText(" " + "  ".repeat(listDepth) + "\u2022 ");
            }
            case "dt" -> appendText(" ");
            case "p" -> {
                var n = node.parent();
                if (!children.isEmpty() && (n == null || !n.nameIs("li")))
                    appendAutoLineBreak("\n\n");
            }
            case "h1", "h2", "h3", "h4", "h5", "h6" -> {
                if (!children.isEmpty())
                    appendAutoLineBreak("\n\n");
            }
            case "hr" -> {
                appendAutoLineBreak("\n\n");
                this.children.add(new Separator());
            }
        }

        appendChildren(node);

        switch (name) {
            case "br", "dd", "h1", "h2", "h3", "h4", "h5", "h6" -> appendAutoLineBreak("\n");
            case "p" -> {
                var n = node.parent();
                if (n == null || !n.nameIs("li"))
                    appendAutoLineBreak("\n");
            }
        }

        return this;
    }

    private static boolean isSpacing(String text) {
        if (text == null)
            return true;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch != ' ' && ch != '\t')
                return false;
        }
        return true;
    }

    public HTMLRenderer mergeLineBreaks() {
        for (int i = 0; i < this.children.size(); i++) {
            javafx.scene.Node child = this.children.get(i);
            if (child instanceof AutoLineBreak) {
                int lastAutoLineBreak = -1;

                for (int j = i + 1; j < this.children.size(); j++) {
                    javafx.scene.Node otherChild = this.children.get(j);

                    if (otherChild instanceof AutoLineBreak) {
                        lastAutoLineBreak = j;
                    } else if (otherChild instanceof Text txt && isSpacing(txt.getText())) {
                        // do nothing
                    } else {
                        break;
                    }
                }

                if (lastAutoLineBreak > 0) {
                    this.children.subList(i + 1, lastAutoLineBreak + 1).clear();

                    if (((Text) child).getText().length() == 1) {
                        ((Text) child).setText("\n\n");
                    }
                }
            }
        }

        {
            // Remove empty lines at the beginning
            int size = children.size();
            for (int i = 0; i < size; i++) {
                var child = children.get(i);
                if (child instanceof AutoLineBreak || child instanceof Text txt && isSpacing(txt.getText())) {
                    // NO-OP
                } else {
                    this.children.subList(0, i).clear();
                    break;
                }
            }
        }
        {
            // Remove empty lines and spaces at the end
            int size = children.size();
            for (int i = size - 1; i > -1; i--) {
                var child = children.get(i);
                if (child instanceof AutoLineBreak || child instanceof Text txt && isSpacing(txt.getText())) {
                    // NO-OP
                } else {
                    this.children.subList(i + 1, size).clear();
                    break;
                }
            }
        }

        return this;
    }

    public TextFlow render() {
        if (rendered) throw new IllegalStateException("Should not render twice");
        rendered = true;
        TextFlow textFlow = new TextFlow();
        textFlow.getStyleClass().add("html");
        textFlow.getChildren().setAll(children);
        for (javafx.scene.Node node : children) {
            if (node instanceof ImagePane imgPane) {
                ImageView img = imgPane.imageView;
                InvalidationListener listener = __ -> img.setFitWidth(Math.min(textFlow.getWidth() * 0.9, img.getImage() == null ? 0D : img.getImage().getWidth()));
                textFlow.widthProperty().addListener(listener);
                img.imageProperty().addListener(listener);
                listener.invalidated(null);
            } else if (node instanceof TableView<?> table) {
                table.prefWidthProperty().bind(textFlow.widthProperty().multiply(0.8));
            } else if (node instanceof CodeFlow codeFlow) {
                codeFlow.maxWidthProperty().bind(textFlow.widthProperty().multiply(0.8));
            } else if (node instanceof Separator separator) {
                separator.prefWidthProperty().bind(textFlow.widthProperty().subtract(24));
            }
        }
        return textFlow;
    }

    private static final class AutoLineBreak extends Text {
        public AutoLineBreak(String text) {
            super(text);
        }
    }

    private static final class ImagePane extends StackPane {

        public final ImageView imageView;

        public ImagePane(ImageView imageView, @Nullable String alt) {
            super();
            this.imageView = imageView;

            var txt = new Text(alt);
            if (StringUtils.isNotBlank(alt)) getChildren().add(txt);
            getChildren().add(imageView);
            FXUtils.onChangeAndOperate(imageView.imageProperty(), img -> {
                if (img != null) getChildren().remove(txt);
            });
        }

    }

    private static final class CodeFlow extends TextFlow {

        public CodeFlow(Text text) {
            super(text);
        }

    }

    private static final class SimpleCssDeclarations {

        @Unmodifiable
        private static final Map<String, String> cssPropertyMapping = Map.of(
                "color", "-fx-fill",
                "font-size", "-fx-font-size"
        );

        private final Map<String, String> declarations = new HashMap<>();

        public void add(String inlineCss) {
            if (StringUtils.isBlank(inlineCss)) return;
            Arrays.stream(inlineCss.split(";")).filter(StringUtils::isNotBlank).forEach(s -> {
                String[] declaration = s.split(":", 2);
                if (declaration.length != 2) return;
                declaration[0] = declaration[0].trim();
                declaration[1] = declaration[1].trim();
                String mappedKey = cssPropertyMapping.get(declaration[0].toLowerCase(Locale.ROOT));
                if (mappedKey != null) {
                    declarations.put(mappedKey, declaration[1]);
                } // Ignore unsupported fields
            });
        }

        public String asString() {
            StringBuilder sb = new StringBuilder();
            declarations.forEach((property, value) -> sb.append(property).append(": ").append(value).append(";"));
            return sb.toString();
        }

    }
}
