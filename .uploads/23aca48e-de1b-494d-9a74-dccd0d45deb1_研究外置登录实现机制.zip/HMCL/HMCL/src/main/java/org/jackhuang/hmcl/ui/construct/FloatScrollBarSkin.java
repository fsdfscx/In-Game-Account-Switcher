/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2020  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui.construct;

import com.jfoenix.utils.JFXNodeUtils;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.NumberBinding;
import javafx.geometry.Orientation;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Skin;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import org.jackhuang.hmcl.ui.FXUtils;
import org.jackhuang.hmcl.ui.animation.AnimationUtils;
import org.jackhuang.hmcl.ui.animation.Motion;
import org.jackhuang.hmcl.util.MathUtils;

// Referenced in root.css
@SuppressWarnings("unused")
public class FloatScrollBarSkin implements Skin<ScrollBar> {
    private ScrollBar scrollBar;
    private Region group;
    private final Rectangle track = new Rectangle();
    private final Rectangle thumb = new Rectangle();

    private BooleanBinding hoverOrPressed;
    private Animation thumbHoverAnimation;

    public FloatScrollBarSkin(final ScrollBar scrollBar) {
        this.scrollBar = scrollBar;
        scrollBar.setPrefHeight(1e-18);
        scrollBar.setPrefWidth(1e-18);

        this.group = new Region() {
            Point2D dragStart;
            double preDragThumbPos;

            final NumberBinding range = Bindings.subtract(scrollBar.maxProperty(), scrollBar.minProperty());
            final NumberBinding position = Bindings.divide(Bindings.subtract(scrollBar.valueProperty(), scrollBar.minProperty()), range);

            {
                // Children are added unmanaged because for some reason the height of the bar keeps changing
                // if they're managed in certain situations... not sure about the cause.
                getChildren().addAll(track, thumb);

                track.setManaged(false);
                track.getStyleClass().add("track");

                thumb.setManaged(false);
                thumb.getStyleClass().add("thumb");

                scrollBar.orientationProperty().addListener(obs -> setup());

                setup();

                thumb.setOnMousePressed(me -> {
                    if (me.isSynthesized()) {
                        // touch-screen events handled by Scroll handler
                        me.consume();
                        return;
                    }
                    /*
                     ** if max isn't greater than min then there is nothing to do here
                     */
                    if (getSkinnable().getMax() > getSkinnable().getMin()) {
                        dragStart = thumb.localToParent(me.getX(), me.getY());
                        double clampedValue = MathUtils.clamp(getSkinnable().getValue(), getSkinnable().getMin(), getSkinnable().getMax());
                        preDragThumbPos = (clampedValue - getSkinnable().getMin()) / (getSkinnable().getMax() - getSkinnable().getMin());
                        me.consume();
                    }
                });


                thumb.setOnMouseDragged(me -> {
                    if (me.isSynthesized()) {
                        // touch-screen events handled by Scroll handler
                        me.consume();
                        return;
                    }
                    /*
                     ** if max isn't greater than min then there is nothing to do here
                     */
                    if (getSkinnable().getMax() > getSkinnable().getMin()) {
                        /*
                         ** if the tracklength isn't greater then do nothing....
                         */
                        if (trackLength() > thumbLength()) {
                            Point2D cur = thumb.localToParent(me.getX(), me.getY());
                            if (dragStart == null) {
                                // we're getting dragged without getting a mouse press
                                dragStart = thumb.localToParent(me.getX(), me.getY());
                            }
                            double dragPos = getSkinnable().getOrientation() == Orientation.VERTICAL ? cur.getY() - dragStart.getY() : cur.getX() - dragStart.getX();
                            double position = preDragThumbPos + dragPos / (trackLength() - thumbLength());
                            if (!getSkinnable().isFocused() && getSkinnable().isFocusTraversable())
                                getSkinnable().requestFocus();
                            double newValue = (position * (getSkinnable().getMax() - getSkinnable().getMin())) + getSkinnable().getMin();
                            if (!Double.isNaN(newValue)) {
                                getSkinnable().setValue(MathUtils.clamp(newValue, getSkinnable().getMin(), getSkinnable().getMax()));
                            }
                        }

                        me.consume();
                    }
                });
            }

            private double trackLength() {
                return getSkinnable().getOrientation() == Orientation.VERTICAL ? track.getHeight() : track.getWidth();
            }

            private double thumbLength() {
                return getSkinnable().getOrientation() == Orientation.VERTICAL ? thumb.getHeight() : thumb.getWidth();
            }

            private void setup() {
                track.widthProperty().unbind();
                track.heightProperty().unbind();

                double offset = 4;

                if (scrollBar.getOrientation() == Orientation.HORIZONTAL) {
                    track.relocate(offset, -6.0);
                    NumberBinding trackWidth = Bindings.max(0, Bindings.subtract(scrollBar.widthProperty(), offset * 2));
                    track.widthProperty().bind(trackWidth);
                    track.setHeight(6.0);
                } else {
                    track.relocate(-6.0, offset);
                    track.setWidth(6.0);
                    NumberBinding trackHeight = Bindings.max(0, Bindings.subtract(scrollBar.heightProperty(), offset * 2));
                    track.heightProperty().bind(trackHeight);
                }

                thumb.xProperty().unbind();
                thumb.yProperty().unbind();
                thumb.widthProperty().unbind();
                thumb.heightProperty().unbind();

                if (scrollBar.getOrientation() == Orientation.HORIZONTAL) {
                    thumb.relocate(0, -6.0);
                    thumb.setHeight(6.0);

                    NumberBinding trackWidth = Bindings.max(0, Bindings.subtract(scrollBar.widthProperty(), offset * 2));

                    thumb.widthProperty().bind(Bindings.min(trackWidth,
                            Bindings.max(20, scrollBar.visibleAmountProperty().divide(range).multiply(trackWidth))));

                    thumb.xProperty().bind(
                            Bindings.add(offset,
                                    Bindings.multiply(
                                            Bindings.max(0, Bindings.subtract(trackWidth, thumb.widthProperty())),
                                            position)
                            )
                    );
                } else {
                    thumb.relocate(-6.0, 0);
                    thumb.setWidth(6.0);

                    NumberBinding trackHeight = Bindings.max(0, Bindings.subtract(scrollBar.heightProperty(), offset * 2));

                    thumb.heightProperty().bind(Bindings.min(trackHeight,
                            Bindings.max(20, scrollBar.visibleAmountProperty().divide(range).multiply(trackHeight))));

                    thumb.yProperty().bind(
                            Bindings.add(offset,
                                    Bindings.multiply(
                                            Bindings.max(0, Bindings.subtract(trackHeight, thumb.heightProperty())),
                                            position)
                            )
                    );
                }
            }

            @Override
            protected double computeMaxWidth(double height) {
                if (scrollBar.getOrientation() == Orientation.HORIZONTAL) {
                    return Double.MAX_VALUE;
                }

                return 6.0;
            }

            @Override
            protected double computeMaxHeight(double width) {
                if (scrollBar.getOrientation() == Orientation.VERTICAL) {
                    return Double.MAX_VALUE;
                }

                return 6.0;
            }
        };

        this.hoverOrPressed = thumb.hoverProperty().or(thumb.pressedProperty());
        FXUtils.onChangeAndOperate(hoverOrPressed, newValue -> {
            if (thumbHoverAnimation != null) {
                thumbHoverAnimation.stop();
                thumbHoverAnimation = null;
            }

            double targetOpacity = newValue ? 1.0 : 0.5;
            double currentOpacity = thumb.getOpacity();

            double opacityAdjustment = targetOpacity - currentOpacity;
            if (Math.abs(opacityAdjustment) < 0.001) {
                if (opacityAdjustment != 0)
                    thumb.setOpacity(targetOpacity);

                return;
            }

            if (AnimationUtils.isAnimationEnabled() && JFXNodeUtils.isTreeVisible(thumb)) {
                thumbHoverAnimation = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(thumb.opacityProperty(), currentOpacity)),
                        new KeyFrame(Motion.SHORT2, new KeyValue(thumb.opacityProperty(), targetOpacity))
                );
                thumbHoverAnimation.play();
            } else {
                thumb.setOpacity(targetOpacity);
            }
        });
    }

    @Override
    public void dispose() {
        if (thumbHoverAnimation != null) {
            thumbHoverAnimation.stop();
            thumbHoverAnimation = null;
        }
        hoverOrPressed = null;
        scrollBar = null;
        group = null;
    }

    @Override
    public Node getNode() {
        return group;
    }

    @Override
    public ScrollBar getSkinnable() {
        return scrollBar;
    }
}
