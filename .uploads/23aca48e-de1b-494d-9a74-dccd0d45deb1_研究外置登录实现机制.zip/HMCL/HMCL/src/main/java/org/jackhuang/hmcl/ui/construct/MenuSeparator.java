/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2020  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui.construct;

import javafx.geometry.Insets;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import org.jackhuang.hmcl.theme.Themes;

public class MenuSeparator extends StackPane {

    public MenuSeparator() {
        Rectangle rect = new Rectangle();
        rect.widthProperty().bind(widthProperty().add(-14));
        rect.setHeight(1);
        rect.fillProperty().bind(Themes.colorSchemeProperty().getOutlineVariant());
        maxHeightProperty().set(10);
        setPadding(new Insets(3));
        getChildren().setAll(rect);
    }
}
