/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2020  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui.download;

import javafx.scene.Node;
import org.jackhuang.hmcl.game.*;
import org.jackhuang.hmcl.modpack.MismatchedModpackTypeException;
import org.jackhuang.hmcl.modpack.Modpack;
import org.jackhuang.hmcl.modpack.ModpackCompletionException;
import org.jackhuang.hmcl.modpack.UnsupportedModpackException;
import org.jackhuang.hmcl.modpack.server.ServerModpackManifest;
import org.jackhuang.hmcl.task.Schedulers;
import org.jackhuang.hmcl.task.Task;
import org.jackhuang.hmcl.ui.Controllers;
import org.jackhuang.hmcl.ui.construct.MessageDialogPane.MessageType;
import org.jackhuang.hmcl.ui.wizard.WizardController;
import org.jackhuang.hmcl.ui.wizard.WizardProvider;
import org.jackhuang.hmcl.util.SettingsMap;
import org.jackhuang.hmcl.util.StringUtils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Path;

import static org.jackhuang.hmcl.util.i18n.I18n.i18n;

public final class ModpackInstallWizardProvider implements WizardProvider {
    private final HMCLGameRepository repository;
    private final Path file;
    private final String updateVersion;
    private String iconUrl;
    private boolean hasSource;

    public ModpackInstallWizardProvider(HMCLGameRepository repository) {
        this(repository, null, null);
    }

    public ModpackInstallWizardProvider(HMCLGameRepository repository, Path modpackFile) {
        this(repository, modpackFile, null);
    }

    public ModpackInstallWizardProvider(HMCLGameRepository repository, GameInstanceID updateInstanceId) {
        this(repository, null, updateInstanceId);
    }

    public ModpackInstallWizardProvider(HMCLGameRepository repository, Path modpackFile, GameInstanceID updateInstanceId) {
        this.repository = repository;
        this.file = modpackFile;
        this.updateVersion = updateInstanceId != null ? updateInstanceId.toString() : null;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    @Override
    public void start(SettingsMap settings) {
        if (file != null)
            settings.put(LocalModpackPage.MODPACK_FILE, file);
        if (updateVersion != null)
            settings.put(LocalModpackPage.MODPACK_NAME, updateVersion);
        if (StringUtils.isNotBlank(iconUrl))
            settings.put(LocalModpackPage.MODPACK_ICON_URL, iconUrl);
        settings.put(ModpackPage.GAME_DIRECTORY, repository.getGameDirectory());
        settings.put(ModpackPage.REPOSITORY, repository);
        hasSource = settings.containsKey(LocalModpackPage.MODPACK_FILE) || settings.containsKey(RemoteModpackPage.MODPACK_SERVER_MANIFEST);
    }

    private Task<?> finishModpackInstallingAsync(SettingsMap settings) {
        Path selected = settings.get(LocalModpackPage.MODPACK_FILE);
        ServerModpackManifest serverModpackManifest = settings.get(RemoteModpackPage.MODPACK_SERVER_MANIFEST);
        Modpack modpack = settings.get(LocalModpackPage.MODPACK_MANIFEST);
        String name = settings.get(LocalModpackPage.MODPACK_NAME);
        String iconUrl = settings.get(LocalModpackPage.MODPACK_ICON_URL);
        Charset charset = settings.get(LocalModpackPage.MODPACK_CHARSET);
        boolean isManuallyCreated = settings.getOrDefault(LocalModpackPage.MODPACK_MANUALLY_CREATED, false);
        var excludedFiles = settings.get(LocalModpackPage.MODPACK_EXCLUDED_FILES);

        if (isManuallyCreated) {
            return ModpackHelper.getInstallManuallyCreatedModpackTask(selected, name, charset);
        }

        if ((selected == null && serverModpackManifest == null) || modpack == null || name == null) return null;

        GameInstanceID instanceId = new GameInstanceID(name);

        if (updateVersion != null) {
            if (selected == null) {
                Controllers.dialog(i18n("modpack.unsupported"), i18n("message.error"), MessageType.ERROR);
                return null;
            }
            try {
                if (serverModpackManifest != null) {
                    return ModpackHelper.getUpdateTask(repository, serverModpackManifest, modpack.getEncoding(), instanceId, ModpackHelper.readModpackConfiguration(repository.getLayout().getModpackConfigurationFile(instanceId)));
                } else {
                    return ModpackHelper.getUpdateTask(repository, selected, modpack.getEncoding(), instanceId, ModpackHelper.readModpackConfiguration(repository.getLayout().getModpackConfigurationFile(instanceId)), excludedFiles);
                }
            } catch (UnsupportedModpackException | ManuallyCreatedModpackException e) {
                Controllers.dialog(i18n("modpack.unsupported"), i18n("message.error"), MessageType.ERROR);
            } catch (MismatchedModpackTypeException e) {
                Controllers.dialog(i18n("modpack.mismatched_type", e.getRequired(), e.getFound()), i18n("message.error"), MessageType.ERROR);
            } catch (IOException e) {
                Controllers.dialog(i18n("modpack.invalid"), i18n("message.error"), MessageType.ERROR);
            }
            return null;
        } else {
            if (serverModpackManifest != null) {
                return ModpackHelper.getInstallTask(repository, serverModpackManifest, instanceId, modpack)
                        .thenRunAsync(Schedulers.javafx(), () -> repository.setSelectedInstance(repository.getInstance(instanceId)));
            } else {
                return ModpackHelper.getInstallTask(repository, selected, instanceId, modpack, iconUrl, excludedFiles)
                        .thenRunAsync(Schedulers.javafx(), () -> repository.setSelectedInstance(repository.getInstance(instanceId)));
            }
        }
    }

    @Override
    public Object finish(SettingsMap settings) {
        settings.put("title", i18n("install.modpack.installation"));
        settings.put("success_message", i18n("install.success"));
        settings.put(FailureCallback.KEY, (ignored, exception, next) -> {
            if (exception instanceof ModpackCompletionException) {
                if (exception.getCause() instanceof FileNotFoundException) {
                    Controllers.dialog(i18n("modpack.type.curse.not_found"), i18n("install.failed"), MessageType.ERROR, next);
                } else {
                    Controllers.dialog(i18n("install.success"), i18n("install.success"), MessageType.SUCCESS, next);
                }
            } else {
                UpdateInstallerWizardProvider.alertFailureMessage(exception, next);
            }
        });

        return finishModpackInstallingAsync(settings);
    }

    private static Node createModpackInstallPage(WizardController controller) {
        if (controller.getSettings().containsKey(LocalModpackPage.MODPACK_FILE))
            return new LocalModpackPage(controller);
        else if (controller.getSettings().containsKey(RemoteModpackPage.MODPACK_SERVER_MANIFEST))
            return new RemoteModpackPage(controller);
        else
            throw new IllegalArgumentException();
    }

    @Override
    public Node createPage(WizardController controller, int step, SettingsMap settings) {
        if (hasSource) {
            return switch (step) {
                case 0 -> createModpackInstallPage(controller);
                default -> throw new IllegalStateException(
                        "error step " + step + ", settings: " + settings + ", pages: " + controller.getPages());
            };
        } else {
            return switch (step) {
                case 0 -> new ModpackSelectionPage(controller);
                case 1 -> createModpackInstallPage(controller);
                default -> throw new IllegalStateException(
                        "error step " + step + ", settings: " + settings + ", pages: " + controller.getPages());
            };
        }
    }

    @Override
    public boolean cancel() {
        return true;
    }
}
