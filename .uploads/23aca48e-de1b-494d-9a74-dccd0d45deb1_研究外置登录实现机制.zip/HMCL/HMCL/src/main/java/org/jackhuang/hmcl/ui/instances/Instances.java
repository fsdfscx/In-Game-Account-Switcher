/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2021  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui.instances;

import com.jfoenix.controls.JFXButton;
import javafx.application.Platform;
import javafx.stage.FileChooser;
import org.jackhuang.hmcl.addon.RemoteAddon;
import org.jackhuang.hmcl.auth.Account;
import org.jackhuang.hmcl.auth.authlibinjector.AuthlibInjectorAccount;
import org.jackhuang.hmcl.download.DefaultDependencyManager;
import org.jackhuang.hmcl.download.DownloadCandidates;
import org.jackhuang.hmcl.download.DownloadProvider;
import org.jackhuang.hmcl.download.game.GameAssetDownloadTask;
import org.jackhuang.hmcl.download.game.GameDownloadTask;
import org.jackhuang.hmcl.download.game.GameLibrariesTask;
import org.jackhuang.hmcl.game.*;
import org.jackhuang.hmcl.setting.*;
import org.jackhuang.hmcl.task.FileDownloadTask;
import org.jackhuang.hmcl.task.Schedulers;
import org.jackhuang.hmcl.task.Task;
import org.jackhuang.hmcl.task.TaskExecutor;
import org.jackhuang.hmcl.ui.Controllers;
import org.jackhuang.hmcl.ui.FXUtils;
import org.jackhuang.hmcl.ui.account.CreateAccountPane;
import org.jackhuang.hmcl.ui.construct.DialogCloseEvent;
import org.jackhuang.hmcl.ui.construct.MessageDialogPane;
import org.jackhuang.hmcl.ui.construct.PromptDialogPane;
import org.jackhuang.hmcl.ui.construct.Validator;
import org.jackhuang.hmcl.ui.download.ModpackInstallWizardProvider;
import org.jackhuang.hmcl.ui.export.ExportWizardProvider;
import org.jackhuang.hmcl.util.StringUtils;
import org.jackhuang.hmcl.util.TaskCancellationAction;
import org.jackhuang.hmcl.util.gson.JsonUtils;
import org.jackhuang.hmcl.util.i18n.I18n;
import org.jackhuang.hmcl.util.io.FileUtils;
import org.jackhuang.hmcl.util.platform.OperatingSystem;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import static org.jackhuang.hmcl.util.i18n.I18n.i18n;
import static org.jackhuang.hmcl.util.logging.Logger.LOG;

public final class Instances {
    private Instances() {
    }

    public static void addNewGame() {
        Controllers.getDownloadPage().showGameDownloads();
        Controllers.navigate(Controllers.getDownloadPage());
    }

    public static void importModpack() {
        HMCLGameRepository repository = GameDirectoryManager.getSelectedRepository();
        if (repository.isLoaded()) {
            Controllers.getDecorator().startWizard(new ModpackInstallWizardProvider(repository), i18n("install.modpack"));
        }
    }

    public static void downloadModpackImpl(DownloadProvider downloadProvider, HMCLGameRepository repository, GameInstanceID instanceId, RemoteAddon mod, RemoteAddon.Version file) {
        Path modpack;
        DownloadCandidates downloadURLs;
        try {
            downloadURLs = downloadProvider.getDownloadCandidates(file.file().url());
            modpack = Files.createTempFile("modpack", ".zip");
        } catch (IOException | IllegalArgumentException e) {
            Controllers.dialog(
                    i18n("install.failed.downloading.detail", file.file().url()) + "\n" + StringUtils.getStackTrace(e),
                    i18n("download.failed.no_code"), MessageDialogPane.MessageType.ERROR);
            return;
        }
        Controllers.taskDialog(
                new FileDownloadTask(downloadURLs, modpack)
                        .setName(file.name())
                        .whenComplete(Schedulers.javafx(), e -> {
                            if (e == null) {
                                ModpackInstallWizardProvider installWizardProvider;
                                if (instanceId != null)
                                    installWizardProvider = new ModpackInstallWizardProvider(repository, modpack, instanceId);
                                else
                                    installWizardProvider = new ModpackInstallWizardProvider(repository, modpack);
                                if (StringUtils.isNotBlank(mod.iconUrl()))
                                    installWizardProvider.setIconUrl(mod.iconUrl());
                                Controllers.getDecorator().startWizard(installWizardProvider);
                            } else if (!(e instanceof CancellationException)) {
                                Controllers.dialog(
                                        i18n("install.failed.downloading.detail", file.file().url()) + "\n" + StringUtils.getStackTrace(e),
                                        i18n("download.failed.no_code"), MessageDialogPane.MessageType.ERROR);
                            }
                        }),
                i18n("message.downloading"),
                TaskCancellationAction.NORMAL
        );
    }

    public static void deleteInstance(HMCLGameInstance gameInstance) {
        HMCLGameRepository repository = gameInstance.getRepository();
        GameInstanceID instanceId = gameInstance.getId();
        boolean isIndependent = gameInstance.getRunDirectory().toAbsolutePath().normalize()
                .equals(gameInstance.getInstanceRoot().toAbsolutePath().normalize());
        String message = isIndependent ? i18n("instance.manage.remove.confirm.independent", instanceId) :
                i18n("instance.manage.remove.confirm.trash", instanceId, instanceId + "_removed");

        JFXButton deleteButton = new JFXButton(i18n("button.delete"));
        deleteButton.getStyleClass().add("dialog-error");
        deleteButton.setOnAction(e -> {
            Task.supplyAsync(Schedulers.io(), () -> repository.removeInstanceFromDisk(instanceId))
                    .whenComplete(Schedulers.javafx(), (result, exception) -> {
                        if (exception != null || !Boolean.TRUE.equals(result)) {
                            Controllers.dialog(i18n("instance.manage.remove.failed"), i18n("message.error"), MessageDialogPane.MessageType.ERROR);
                        }
                    }).start();
        });

        Controllers.confirmAction(message, i18n("message.warning"), MessageDialogPane.MessageType.WARNING, deleteButton);
    }

    public static CompletableFuture<String> renameInstance(HMCLGameInstance gameInstance) {
        HMCLGameRepository repository = gameInstance.getRepository();
        GameInstanceID instanceId = gameInstance.getId();
        return Controllers.prompt(i18n("instance.manage.rename.message"), (newName, handler) -> {
            if (newName.equals(instanceId.toString())) {
                handler.resolve();
                return;
            }
            GameInstanceID oldInstanceId = instanceId;
            GameInstanceID newInstanceId = new GameInstanceID(newName);
            if (repository.renameInstance(oldInstanceId, newInstanceId)) {
                handler.resolve();
                repository.refreshAsync()
                        .thenRunAsync(Schedulers.javafx(), () -> {
                            if (repository.hasInstance(newInstanceId)) {
                                repository.setSelectedInstance(repository.getInstance(newInstanceId));
                            }
                        }).start();
            } else {
                handler.reject(i18n("instance.manage.rename.fail"));
            }
        }, instanceId.toString(),
            new Validator(i18n("install.new_game.malformed"), HMCLGameRepository::isValidInstanceId),
            new Validator(i18n("install.new_game.already_exists"), newVersionName -> !repository.instanceIdConflicts(newVersionName) || newVersionName.equals(instanceId.toString())));
    }

    public static void exportInstance(HMCLGameInstance gameInstance) {
        Controllers.getDecorator().startWizard(new ExportWizardProvider(gameInstance), i18n("modpack.wizard"));
    }

    public static void openFolder(HMCLGameInstance gameInstance) {
        FXUtils.openFolder(gameInstance.getRunDirectory());
    }

    public static void installFromJson(HMCLGameRepository repository, Path file) {
        GameInstanceManifest manifest;
        try {
            manifest = JsonUtils.fromJsonFile(file, GameInstanceManifest.class);
            if (manifest == null)
                throw new IllegalArgumentException("Missing game manifest");
            if (manifest.inheritsFrom() != null)
                throw new IllegalArgumentException("Game manifest inherits from another manifest");
        } catch (Exception e) {
            LOG.warning("Failed to read game manifest from " + file, e);
            Controllers.dialog(i18n("install.new_game.malformed_json"), i18n("message.error"), MessageDialogPane.MessageType.ERROR);
            return;
        }

        Controllers.prompt(i18n("instance.manage.duplicate.prompt"), (result, handler) -> {
            handler.resolve();

            GameInstanceID instanceId = new GameInstanceID(result);

            DefaultDependencyManager dependencyManager = repository.getDependency();
            GameInstanceManifest newManifest = manifest.withId(instanceId).withJar(instanceId);
            GameDownloadTask gameDownloadTask = new GameDownloadTask(
                    dependencyManager,
                    newManifest);
            AtomicReference<GameRepositoryDraft> activeDraft = new AtomicReference<>();

            Controllers.taskDialog(
                    Task.supplyAsync(() -> {
                                GameRepositoryDraft draft = repository.openDraft();
                                activeDraft.set(draft);
                                return draft;
                            })
                            .thenComposeAsync(draft -> Task.allOf(
                                    gameDownloadTask,
                                    Task.allOf(
                                            new GameAssetDownloadTask(
                                                    dependencyManager,
                                                    newManifest,
                                                    GameAssetDownloadTask.DOWNLOAD_INDEX_FORCIBLY,
                                                    true),
                                            new GameLibrariesTask(dependencyManager, newManifest, true))
                                            .withRunAsync(() -> {
                                                // ignore failure
                                            })))
                            .thenAcceptAsync(ignored -> {
                                GameRepositoryDraft draft = activeDraft.get();
                                if (draft == null) {
                                    throw new IllegalStateException("Game repository draft is unavailable");
                                }
                                draft.put(newManifest);
                                draft.putPrimaryJar(instanceId, gameDownloadTask.getResult());
                                draft.commit();
                            })
                            .whenComplete(exception -> {
                                GameRepositoryDraft draft = activeDraft.getAndSet(null);
                                if (draft != null && draft.isOpen()) {
                                    draft.abort();
                                }
                            })
                            .whenComplete(Schedulers.javafx(), (exception) -> {
                                if (exception == null) {
                                    repository.setSelectedInstance(repository.getInstance(instanceId));
                                } else {
                                    Controllers.dialog(
                                            I18n.localizeErrorMessage(exception), i18n("install.failed"), MessageDialogPane.MessageType.ERROR);
                                }
                            }), i18n("install.new_game"), TaskCancellationAction.NORMAL);
        }, FileUtils.getNameWithoutExtension(file), new Validator(i18n("install.new_game.malformed"), HMCLGameRepository::isValidInstanceId), new Validator(i18n("install.new_game.already_exists"), newVersionName -> !repository.instanceIdConflicts(newVersionName)));
    }

    public static void duplicateInstance(HMCLGameInstance gameInstance) {
        HMCLGameRepository repository = gameInstance.getRepository();
        GameInstanceID instanceId = gameInstance.getId();
        Controllers.prompt(
                new PromptDialogPane.Builder(i18n("instance.manage.duplicate.prompt"), (res, handler) -> {
                    String newInstanceName = ((PromptDialogPane.Builder.StringQuestion) res.get(1)).getValue();
                    GameInstanceID newInstanceId = new GameInstanceID(newInstanceName);
                    boolean copySaves = ((PromptDialogPane.Builder.BooleanQuestion) res.get(2)).getValue();
                    Task.runAsync(() -> repository.duplicateInstance(instanceId, newInstanceId, copySaves))
                            .thenComposeAsync(repository.refreshAsync())
                            .whenComplete(Schedulers.javafx(), (result, exception) -> {
                                if (exception == null) {
                                    handler.resolve();
                                } else {
                                    handler.reject(StringUtils.getStackTrace(exception));
                                    if (!repository.instanceIdConflicts(newInstanceId)) {
                                        repository.removeInstanceFromDisk(newInstanceId);
                                    }
                                }
                            }).start();
                })
                        .addQuestion(new PromptDialogPane.Builder.HintQuestion(i18n("instance.manage.duplicate.confirm")))
                        .addQuestion(new PromptDialogPane.Builder.StringQuestion(null, instanceId.toString(),
                                new Validator(i18n("install.new_game.malformed"), HMCLGameRepository::isValidInstanceId),
                                new Validator(i18n("install.new_game.already_exists"), newVersionName -> !repository.instanceIdConflicts(newVersionName))))
                        .addQuestion(new PromptDialogPane.Builder.BooleanQuestion(i18n("instance.manage.duplicate.duplicate_save"), false)));
    }

    public static void updateInstance(HMCLGameInstance gameInstance) {
        Controllers.getDecorator().startWizard(new ModpackInstallWizardProvider(gameInstance.getRepository(), gameInstance.getId()));
    }

    public static void updateGameAssets(HMCLGameInstance gameInstance) {
        TaskExecutor executor = new GameAssetDownloadTask(
                gameInstance.getRepository().getDependency(),
                gameInstance.getResolvedManifest(),
                GameAssetDownloadTask.DOWNLOAD_INDEX_FORCIBLY,
                true).executor();
        Controllers.taskDialog(executor, i18n("instance.manage.redownload_assets_index"), TaskCancellationAction.NO_CANCEL);
        executor.start();
    }

    public static void cleanInstance(HMCLGameInstance gameInstance) {
        try {
            gameInstance.getRepository().clean(gameInstance.getId());
        } catch (IOException e) {
            LOG.warning("Unable to clean game directory", e);
        }
    }

    @SafeVarargs
    public static void generateLaunchScript(HMCLGameInstance gameInstance, Consumer<LauncherHelper>... injecters) {
        ensureSelectedAccount(account -> {
            Path runDirectory = gameInstance.getRunDirectory();
            FileChooser chooser = new FileChooser();
            if (Files.isDirectory(runDirectory))
                chooser.setInitialDirectory(runDirectory.toFile());
            chooser.setTitle(i18n("instance.launch_script.save"));
            if (OperatingSystem.CURRENT_OS == OperatingSystem.MACOS) {
                chooser.getExtensionFilters().add(
                        new FileChooser.ExtensionFilter(i18n("extension.command"), "*.command")
                );
            }
            chooser.getExtensionFilters().add(OperatingSystem.CURRENT_OS == OperatingSystem.WINDOWS
                    ? new FileChooser.ExtensionFilter(i18n("extension.bat"), "*.bat")
                    : new FileChooser.ExtensionFilter(i18n("extension.sh"), "*.sh"));
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(i18n("extension.ps1"), "*.ps1"));
            Path file = Controllers.showSaveDialog(chooser);
            if (file != null) {
                if (!isValidScriptExtension(FileUtils.getExtension(file))) {
                    String defaultExt = getDefaultScriptExtension();
                    file = file.resolveSibling(file.getFileName().toString() + "." + defaultExt);
                }

                LauncherHelper launcherHelper = new LauncherHelper(gameInstance, account);
                for (Consumer<LauncherHelper> injecter : injecters) {
                    injecter.accept(launcherHelper);
                }
                launcherHelper.makeLaunchScript(file);
            }
        });
    }

    private static boolean isValidScriptExtension(String ext) {
        if (OperatingSystem.CURRENT_OS == OperatingSystem.WINDOWS) {
            return ext.equalsIgnoreCase("bat") || ext.equalsIgnoreCase("ps1");
        }
        return ext.equalsIgnoreCase("sh") || ext.equalsIgnoreCase("bash") || ext.equalsIgnoreCase("command") || ext.equalsIgnoreCase("ps1");
    }

    private static String getDefaultScriptExtension() {
        return switch (OperatingSystem.CURRENT_OS) {
            case WINDOWS -> "bat";
            case MACOS -> "command";
            default -> "sh";
        };
    }

    /// Launches the given instance after ensuring that an account is selected.
    ///
    /// If `gameInstance` is `null`, an error dialog is shown and no account selection or launch is
    /// attempted.
    ///
    /// @param gameInstance the instance to launch, or `null` when no instance is available
    /// @param injecters callbacks that configure the launcher before launch
    @SafeVarargs
    public static void launch(@Nullable HMCLGameInstance gameInstance, Consumer<LauncherHelper>... injecters) {
        if (gameInstance == null) {
            JFXButton gotoDownload = new JFXButton(i18n("instance.empty.launch.goto_download"));
            gotoDownload.getStyleClass().add("dialog-accept");
            gotoDownload.setOnAction(e -> Controllers.navigate(Controllers.getDownloadPage()));

            Controllers.confirmAction(i18n("instance.empty.launch"), i18n("launch.failed"),
                    MessageDialogPane.MessageType.ERROR,
                    gotoDownload,
                    null);
            return;
        }

        ensureSelectedAccount(account -> {
            LauncherHelper launcherHelper = new LauncherHelper(gameInstance, account);
            for (Consumer<LauncherHelper> injecter : injecters) {
                injecter.accept(launcherHelper);
            }
            launcherHelper.launch();
        });
    }

    public static void testGame(HMCLGameInstance gameInstance) {
        launch(gameInstance, LauncherHelper::setTestMode);
    }

    public static void launchAndEnterWorld(HMCLGameInstance gameInstance, String worldFolderName) {
        launch(gameInstance, launcherHelper ->
                launcherHelper.setQuickPlayOption(new QuickPlayOption.SinglePlayer(worldFolderName)));
    }

    public static void generateLaunchScriptForQuickEnterWorld(HMCLGameInstance gameInstance, String worldFolderName) {
        generateLaunchScript(gameInstance, launcherHelper ->
                launcherHelper.setQuickPlayOption(new QuickPlayOption.SinglePlayer(worldFolderName)));
    }

    private static void ensureSelectedAccount(Consumer<Account> action) {
        Account account = Accounts.getSelectedAccount();
        if (SettingsManager.isNewlyCreated() && !AuthlibInjectorServers.getServers().isEmpty() &&
                !(account instanceof AuthlibInjectorAccount && AuthlibInjectorServers.getServers().contains(((AuthlibInjectorAccount) account).getServer()))) {
            CreateAccountPane dialog = new CreateAccountPane(AuthlibInjectorServers.getServers().iterator().next());
            dialog.addEventHandler(DialogCloseEvent.CLOSE, e -> {
                Account newAccount = Accounts.getSelectedAccount();
                if (newAccount == null) {
                    // user cancelled operation
                } else {
                    Platform.runLater(() -> action.accept(newAccount));
                }
            });
            Controllers.dialog(dialog);
        } else if (account == null) {
            CreateAccountPane dialog = new CreateAccountPane();
            dialog.addEventHandler(DialogCloseEvent.CLOSE, e -> {
                Account newAccount = Accounts.getSelectedAccount();
                if (newAccount == null) {
                    // user cancelled operation
                } else {
                    Platform.runLater(() -> action.accept(newAccount));
                }
            });
            Controllers.dialog(dialog);
        } else {
            action.accept(account);
        }
    }

    public static void modifyGlobalSettings(HMCLGameRepository repository) {
        Controllers.getSettingsPage().showGameSettings(repository);
        Controllers.navigate(Controllers.getSettingsPage());
    }

    public static void modifyGameSettings(HMCLGameInstance gameInstance) {
        Controllers.getGameInstancePage().setInstance(gameInstance.getId(), gameInstance.getRepository());
        Controllers.getGameInstancePage().showInstanceSettings();
        // VersionPage.loadVersion will be invoked after navigation
        Controllers.navigate(Controllers.getGameInstancePage());
    }

}
