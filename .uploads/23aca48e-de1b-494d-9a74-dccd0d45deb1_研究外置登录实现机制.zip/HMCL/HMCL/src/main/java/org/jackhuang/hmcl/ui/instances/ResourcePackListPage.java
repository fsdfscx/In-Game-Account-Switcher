/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2025  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui.instances;

import com.jfoenix.controls.*;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.util.Duration;
import org.jackhuang.hmcl.addon.LocalAddonFile;
import org.jackhuang.hmcl.addon.RemoteAddon;
import org.jackhuang.hmcl.addon.RemoteAddonRepository;
import org.jackhuang.hmcl.addon.repository.CurseForgeRemoteAddonRepository;
import org.jackhuang.hmcl.addon.repository.ModrinthRemoteAddonRepository;
import org.jackhuang.hmcl.addon.resourcepack.ResourcePackFile;
import org.jackhuang.hmcl.addon.resourcepack.ResourcePackManager;
import org.jackhuang.hmcl.game.HMCLGameInstance;
import org.jackhuang.hmcl.setting.DownloadProviders;
import org.jackhuang.hmcl.setting.SettingsManager;
import org.jackhuang.hmcl.task.Schedulers;
import org.jackhuang.hmcl.task.Task;
import org.jackhuang.hmcl.ui.Controllers;
import org.jackhuang.hmcl.ui.FXUtils;
import org.jackhuang.hmcl.ui.ListPageBase;
import org.jackhuang.hmcl.ui.SVG;
import org.jackhuang.hmcl.ui.WeakListenerHolder;
import org.jackhuang.hmcl.ui.animation.ContainerAnimations;
import org.jackhuang.hmcl.ui.animation.TransitionPane;
import org.jackhuang.hmcl.ui.construct.*;
import org.jackhuang.hmcl.util.*;
import org.jackhuang.hmcl.util.javafx.ItemPropertyAsyncCache;
import org.jackhuang.hmcl.util.versioning.GameVersionNumber;
import org.jetbrains.annotations.NotNullByDefault;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.nio.file.Path;
import java.util.*;
import java.util.Objects;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static org.jackhuang.hmcl.ui.FXUtils.ignoreEvent;
import static org.jackhuang.hmcl.ui.FXUtils.onEscPressed;
import static org.jackhuang.hmcl.ui.ToolbarListPageSkin.createToolbarButton2;
import static org.jackhuang.hmcl.util.Pair.pair;
import static org.jackhuang.hmcl.util.i18n.I18n.i18n;
import static org.jackhuang.hmcl.util.logging.Logger.LOG;

public final class ResourcePackListPage extends ListPageBase<ResourcePackListPage.ResourcePackInfoObject> {

    private static final String TIP_KEY = "resourcePackWarning";
    private static @Nullable String getWarning(ResourcePackFile.Compatibility compatibility) {
        return switch (compatibility) {
            case TOO_NEW -> i18n("resourcepack.warning.too_new");
            case TOO_OLD -> i18n("resourcepack.warning.too_old");
            case INVALID -> i18n("resourcepack.warning.invalid");
            case MISSING_PACK_META -> i18n("resourcepack.warning.missing_pack_meta");
            case MISSING_GAME_META -> i18n("resourcepack.warning.missing_game_meta");
            default -> null;
        };
    }

    private final WeakListenerHolder listenerHolder = new WeakListenerHolder();
    private @Nullable HMCLGameInstance gameInstance;

    private Path resourcePackDirectory;
    private ResourcePackManager resourcePackManager;

    private final ReentrantLock lock = new ReentrantLock();

    /// Creates a resource-pack list that reloads when `instanceContext` changes.
    ///
    /// @param instanceContext the parent page's instance property
    public ResourcePackListPage(ObservableValue<? extends HMCLGameInstance.Optional> instanceContext) {
        Objects.requireNonNull(instanceContext, "instanceContext");
        FXUtils.applyDragListener(this, ResourcePackFile::isFileResourcePack, this::addFiles);

        listenerHolder.add(FXUtils.onWeakChangeAndOperate(instanceContext, current -> {
            if (current != null) {
                loadInstance(current);
            }
        }));
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ResourcePackListPageSkin(this);
    }

    public void loadInstance(HMCLGameInstance.Optional instance) {
        this.gameInstance = instance.instance();
        if (gameInstance == null) {
            this.resourcePackManager = null;
            this.resourcePackDirectory = null;
            getItems().clear();
            return;
        }

        this.resourcePackManager = gameInstance.getResourcePackManager();
        this.resourcePackDirectory = this.resourcePackManager.getDirectory();

        refresh();
    }

    public void refresh() {
        if (resourcePackManager == null) return;
        setDisable(false);
        setLoading(true);
        Task.supplyAsync(Schedulers.io(), () -> {
            lock.lock();
            try {
                if (!ResourcePackManager.isMcVersionSupported(resourcePackManager.getMinecraftVersion())) return null;
                resourcePackManager.refresh();
                return resourcePackManager.arePacksEnabled(resourcePackManager.getLocalFiles().stream())
                        .map(ResourcePackInfoObject::new)
                        .toList();
            } finally {
                lock.unlock();
            }
        }).whenComplete(Schedulers.javafx(), (result, exception) -> {
            if (exception == null) {
                if (result != null) {
                    getItems().setAll(result);
                } else { // Unsupported mc version
                    getItems().clear();
                    setDisable(true);
                }
            } else {
                LOG.warning("Failed to load resource packs", exception);
                getItems().clear();
            }
            setLoading(false);
        }).start();
    }

    public void addFiles(List<Path> files) {
        if (resourcePackManager == null) return;

        List<Path> failures = new ArrayList<>();
        Task.runAsync(() -> {
            for (Path file : files) {
                try {
                    resourcePackManager.importResourcePack(file);
                } catch (Exception e) {
                    LOG.warning("Failed to add resource pack", e);
                    failures.add(file);
                }
            }
        }).withRunAsync(Schedulers.javafx(), () -> {
            if (!failures.isEmpty()) {
                StringBuilder failure = new StringBuilder(i18n("resourcepack.add.failed"));
                for (Path file: failures) {
                    failure.append("\n").append(file.toString());
                }
                Controllers.dialog(failure.toString(), i18n("message.error"), MessageDialogPane.MessageType.ERROR);
            }
            refresh();
        }).start();

    }

    public void onAddFiles() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(i18n("resourcepack.add"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(i18n("resourcepack"), "*.zip"));
        List<Path> files = Controllers.showOpenMultipleDialog(fileChooser);
        if (files != null && !files.isEmpty()) {
            addFiles(files);
        }
    }

    private void onDownload() {
        if (gameInstance == null) {
            return;
        }
        Controllers.getDownloadPage().showResourcePackDownloads().selectInstance(gameInstance.getId());
        Controllers.navigate(Controllers.getDownloadPage());
    }

    private void onOpenFolder() {
        if (resourcePackDirectory != null) {
            FXUtils.openFolder(resourcePackDirectory);
        }
    }

    private void setSelectedEnabled(List<ResourcePackInfoObject> selectedItems, boolean enabled) {
        if (!Boolean.TRUE.equals(SettingsManager.state().getShownTips().get(TIP_KEY)) && enabled && !selectedItems.stream().map(ResourcePackInfoObject::getFile).allMatch(ResourcePackFile::isCompatible)) {
            Controllers.confirm(
                    i18n("resourcepack.warning.manipulate"),
                    i18n("message.warning"),
                    MessageDialogPane.MessageType.WARNING,
                    () -> {
                        SettingsManager.state().getShownTips().put(TIP_KEY, true);
                        setSelectedEnabled(selectedItems, true);
                    }, null);
        } else {
            if (resourcePackManager == null) return;
            if (enabled) {
                resourcePackManager.enableResourcePacks(selectedItems.stream().map(ResourcePackInfoObject::getFile).toList());
            } else {
                resourcePackManager.disableResourcePacks(selectedItems.stream().map(ResourcePackInfoObject::getFile).toList());
            }
            for (ResourcePackInfoObject item : selectedItems) {
                item.enabledProperty().set(enabled);
            }
        }
    }

    private void removeSelected(List<ResourcePackInfoObject> selectedItems) {
        try {
            if (resourcePackManager != null) {
                if (resourcePackManager.removeResourcePacks(selectedItems.stream().map(ResourcePackInfoObject::getFile).toList())) {
                    refresh();
                }
            }
        } catch (IOException e) {
            Controllers.dialog(i18n("resourcepack.delete.failed", e.getMessage()), i18n("message.error"), MessageDialogPane.MessageType.ERROR);
            LOG.warning("Failed to delete resource packs", e);
        }
    }

    public void checkUpdates(Collection<ResourcePackFile> resourcePacks) {
        HMCLGameInstance gameInstance = this.gameInstance;
        if (gameInstance == null) {
            return;
        }

        Runnable action = () -> Controllers.taskDialog(Task
                        .composeAsync(() -> {
                            GameVersionNumber version = gameInstance.getVersion();
                            return version != GameVersionNumber.unknown()
                                    ? new AddonCheckUpdatesTask<>(DownloadProviders.getDownloadProvider(),
                                            version.toString(), resourcePacks)
                                    : null;
                        })
                        .whenComplete(Schedulers.javafx(), (result, exception) -> {
                            if (exception != null || result == null) {
                                Controllers.dialog(i18n("addon.check_update.failed_check"), i18n("message.failed"), MessageDialogPane.MessageType.ERROR);
                            } else if (result.isEmpty()) {
                                Controllers.dialog(i18n("addon.check_update.empty"));
                            } else {
                                Controllers.navigateForward(new AddonUpdatesPage<>(resourcePackManager, result));
                            }
                        })
                        .withStagesHints("update.checking"),
                i18n("addon.check_update"), TaskCancellationAction.NORMAL);

        if (gameInstance.isModpack()) {
            Controllers.confirm(
                    i18n("resourcepack.update_in_modpack.warning"), null,
                    MessageDialogPane.MessageType.WARNING,
                    action, null);
        } else {
            action.run();
        }
    }

    @NotNullByDefault
    private static final class ResourcePackListPageSkin extends SkinBase<ResourcePackListPage> {
        private final JFXListView<ResourcePackInfoObject> listView;
        private final JFXTextField searchField = new JFXTextField();

        private final TransitionPane toolbarPane = new TransitionPane();
        private final HBox searchBar = new HBox();
        private final HBox toolbarNormal = new HBox();
        private final HBox toolbarSelecting = new HBox();

        /// Whether the search mechanism is currently active.
        private final BooleanProperty isSearching = new SimpleBooleanProperty(false);

        /// Timer for debouncing search input to avoid executing search on every keystroke.
        private final PauseTransition searchPause = new PauseTransition(Duration.millis(100));

        private ResourcePackListPageSkin(ResourcePackListPage control) {
            super(control);

            StackPane pane = new StackPane();
            pane.setPadding(new Insets(10));
            pane.getStyleClass().addAll("notice-pane");

            ComponentList root = new ComponentList();
            root.getStyleClass().add("no-padding");

            listView = new JFXListView<>();

            {

                // Toolbar Selecting
                toolbarSelecting.getChildren().setAll(
                        createToolbarButton2(i18n("button.remove"), SVG.DELETE_FOREVER, () -> {
                            Controllers.confirm(i18n("button.remove.confirm"), i18n("button.remove"), () -> {
                                control.removeSelected(listView.getSelectionModel().getSelectedItems());
                            }, null);
                        }),
                        createToolbarButton2(i18n("button.enable"), SVG.CHECK, () ->
                                control.setSelectedEnabled(listView.getSelectionModel().getSelectedItems(), true)),
                        createToolbarButton2(i18n("button.disable"), SVG.CLOSE, () ->
                                control.setSelectedEnabled(listView.getSelectionModel().getSelectedItems(), false)),
                        createToolbarButton2(i18n("addon.check_update.button"), SVG.UPDATE, () ->
                                control.checkUpdates(
                                        listView.getSelectionModel().getSelectedItems().stream().map(ResourcePackInfoObject::getFile).toList()
                                )
                        ),
                        createToolbarButton2(i18n("button.select_all"), SVG.SELECT_ALL, () ->
                                listView.getSelectionModel().selectAll()),
                        createToolbarButton2(i18n("button.cancel"), SVG.CANCEL, () ->
                                listView.getSelectionModel().clearSelection())
                );

                // Search Bar
                searchBar.setAlignment(Pos.CENTER);
                searchBar.setPadding(new Insets(0, 5, 0, 5));
                searchField.setPromptText(i18n("search"));
                HBox.setHgrow(searchField, Priority.ALWAYS);
                searchPause.setOnFinished(e -> search());
                FXUtils.onChange(searchField.textProperty(), newValue -> {
                    if (isSearching.get() || !StringUtils.isBlank(newValue)) {
                        searchPause.setRate(1);
                        searchPause.playFromStart();
                    }
                });

                JFXButton closeSearchBar = createToolbarButton2(null, SVG.CLOSE,
                        () -> {
                            changeToolbar(toolbarNormal);

                            searchField.clear();
                            searchPause.stop();

                            isSearching.set(false);
                            Bindings.bindContent(listView.getItems(), getSkinnable().getItems());
                        });

                onEscPressed(searchField, closeSearchBar::fire);

                searchBar.getChildren().setAll(searchField, closeSearchBar);

                // Toolbar Normal
                toolbarNormal.setAlignment(Pos.CENTER_LEFT);
                toolbarNormal.setPickOnBounds(false);
                toolbarNormal.getChildren().setAll(
                        createToolbarButton2(i18n("button.refresh"), SVG.REFRESH, control::refresh),
                        createToolbarButton2(i18n("resourcepack.add"), SVG.ADD, control::onAddFiles),
                        createToolbarButton2(i18n("button.reveal_dir"), SVG.FOLDER_OPEN, control::onOpenFolder),
                        createToolbarButton2(i18n("addon.check_update.button"), SVG.UPDATE, () ->
                                control.checkUpdates(listView.getItems().stream().map(ResourcePackInfoObject::getFile).toList())
                        ),
                        createToolbarButton2(i18n("resourcepack.download"), SVG.DOWNLOAD, control::onDownload),
                        createToolbarButton2(i18n("search"), SVG.SEARCH, () -> changeToolbar(searchBar))
                );

                FXUtils.onChangeAndOperate(listView.getSelectionModel().selectedItemProperty(),
                        selectedItem -> {
                            if (selectedItem == null)
                                changeToolbar(isSearching.get() ? searchBar : toolbarNormal);
                            else
                                changeToolbar(toolbarSelecting);
                        });
                FXUtils.setOverflowHidden(toolbarPane, 8);
                root.getContent().add(toolbarPane);

                // Clear selection when pressing ESC
                root.addEventHandler(KeyEvent.KEY_PRESSED, e -> {
                    if (e.getCode() == KeyCode.ESCAPE) {
                        if (listView.getSelectionModel().getSelectedItem() != null) {
                            listView.getSelectionModel().clearSelection();
                            e.consume();
                        }
                    }
                });
            }

            {
                SpinnerPane center = new SpinnerPane();
                ComponentList.setVgrow(center, Priority.ALWAYS);
                center.loadingProperty().bind(control.loadingProperty());

                listView.setCellFactory(x -> new ResourcePackListCell(listView, control));
                listView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

                StackPane placeholderContainer = new StackPane();
                placeholderContainer.getStyleClass().add("notice-pane");
                Label placeholderLabel = new Label(i18n("resourcepack.empty"));
                placeholderLabel.textProperty().bind(
                    Bindings.createStringBinding(() -> {
                        if (isSearching.get()) {
                            return i18n("search.no_results_found");
                        } else {
                            return i18n("resourcepack.empty");
                        }
                    },
                    isSearching)
                );
                placeholderContainer.getChildren().add(placeholderLabel);
                listView.setPlaceholder(placeholderContainer);

                Bindings.bindContent(listView.getItems(), control.getItems());

                listView.setOnContextMenuRequested(event -> {
                    ResourcePackInfoObject selectedItem = listView.getSelectionModel().getSelectedItem();
                    if (selectedItem != null && listView.getSelectionModel().getSelectedItems().size() == 1) {
                        listView.getSelectionModel().clearSelection();
                        Controllers.dialog(new ResourcePackInfoDialog(selectedItem));
                    }
                });

                ignoreEvent(listView, KeyEvent.KEY_PRESSED, e -> e.getCode() == KeyCode.ESCAPE);
                listView.getStyleClass().add("no-horizontal-scrollbar");

                center.setContent(listView);
                root.getContent().add(center);
            }

            pane.getChildren().setAll(root);
            getChildren().setAll(pane);
        }

        private void changeToolbar(HBox newToolbar) {
            Node oldToolbar = toolbarPane.getCurrentNode();
            if (newToolbar != oldToolbar) {
                toolbarPane.setContent(newToolbar, ContainerAnimations.FADE);
                if (newToolbar == searchBar) {
                    Platform.runLater(searchField::requestFocus);
                }
            }
        }

        private void search() {
            isSearching.set(true);

            Bindings.unbindContent(listView.getItems(), getSkinnable().getItems());

            String queryString = searchField.getText();
            if (StringUtils.isBlank(queryString)) {
                listView.getItems().setAll(getSkinnable().getItems());
            } else {
                listView.getItems().clear();

                Predicate<@Nullable String> predicate;
                try {
                    predicate = StringUtils.compileQuery(queryString);
                } catch (Throwable e) {
                    LOG.warning("Illegal regular expression", e);
                    return;
                }

                // Do we need to search in the background thread?
                for (ResourcePackInfoObject item : getSkinnable().getItems()) {
                    ResourcePackFile resourcePack = item.getFile();
                    LocalAddonFile.Description description = resourcePack.getDescription();
                    Stream<String> descriptionParts = description == null
                            ? Stream.empty()
                            : description.getParts().stream().map(LocalAddonFile.Description.Part::getText);
                    if (predicate.test(resourcePack.getFileNameWithExtension())
                            || predicate.test(resourcePack.getFileName())
                            || descriptionParts.anyMatch(predicate)) {
                        listView.getItems().add(item);
                    }
                }
            }
        }
    }

    public static final class ResourcePackInfoObject {

        private final ResourcePackFile file;
        private final BooleanProperty enabled;

        private final ItemPropertyAsyncCache<Image, ResourcePackInfoObject> iconCache;

        public ResourcePackInfoObject(Pair<ResourcePackFile, Boolean> pair) {
            this.file = pair.key();
            this.enabled = new SimpleBooleanProperty(this, "enabled", pair.value());

            this.iconCache = new ItemPropertyAsyncCache.Soft<>(this, this::loadIcon, this::getDefaultIcon);
        }

        public ResourcePackFile getFile() {
            return file;
        }

        public BooleanProperty enabledProperty() {
            return enabled;
        }

        private Image getDefaultIcon() {
            return FXUtils.newBuiltinImage("/assets/img/unknown_pack.png");
        }

        private Image loadIcon() {
            Image icon = file.loadIcon();
            if (icon != null && !icon.isError() && icon.getWidth() > 0 && icon.getHeight() > 0 && Math.abs(icon.getWidth() - icon.getHeight()) < 1) {
                return icon;
            }
            return getDefaultIcon();
        }
    }

    private static final class ResourcePackListCell extends MDListCell<ResourcePackInfoObject> {
        private static final PseudoClass WARNING = PseudoClass.getPseudoClass("warning");

        private final ResourcePackListPage page;

        private final JFXCheckBox checkBox;
        private final ImageContainer imageContainer = new ImageContainer(32);
        private final TwoLineListItem content = new TwoLineListItem();
        private final JFXButton btnReveal = FXUtils.newToggleButton4(SVG.FOLDER);
        private final JFXButton btnInfo = FXUtils.newToggleButton4(SVG.INFO);

        private BooleanProperty booleanProperty = null;

        public ResourcePackListCell(JFXListView<ResourcePackInfoObject> listView, ResourcePackListPage page) {
            super(listView);
            this.page = page;

            getStyleClass().add("resource-pack-list-cell");

            HBox root = new HBox(8);
            root.setPickOnBounds(false);
            root.setAlignment(Pos.CENTER_LEFT);

            checkBox = new JFXCheckBox() {
                @Override
                public void fire() {
                    if (!Boolean.TRUE.equals(SettingsManager.state().getShownTips().get(TIP_KEY)) && !isSelected() && getItem() != null && !getItem().getFile().isCompatible()) {
                        Controllers.confirm(
                                i18n("resourcepack.warning.manipulate"),
                                i18n("message.info"),
                                MessageDialogPane.MessageType.INFO,
                                () -> {
                                    super.fire();
                                    SettingsManager.state().getShownTips().put(TIP_KEY, true);
                                }, null);
                    } else {
                        super.fire();
                    }
                }
            };
            checkBox.setOnAction(e -> {
                if (getItem() != null) getItem().getFile().setEnabled(checkBox.isSelected());
            });

            HBox.setHgrow(content, Priority.ALWAYS);
            content.setMouseTransparent(true);

            root.getChildren().setAll(checkBox, imageContainer, content, btnReveal, btnInfo);

            setSelectable();

            StackPane.setMargin(root, new Insets(8));
            getContainer().getChildren().add(root);
        }

        @Override
        protected void updateControl(ResourcePackInfoObject item, boolean empty) {
            pseudoClassStateChanged(WARNING, false);

            if (empty || item == null) return;

            ResourcePackFile file = item.getFile();
            item.iconCache.attachValue(imageContainer.imageProperty(), new WeakReference<>(itemProperty()));

            content.getTags().clear();
            content.setTitle(file.getFileName());
            {
                var description = file.getDescription();
                content.setSubtitle(description != null ? description.toStringSingleLine() : "");
            }

            FXUtils.installFastTooltip(btnReveal, i18n("reveal.in_file_manager"));
            btnReveal.setOnAction(event -> FXUtils.showFileInExplorer(file.getFile()));

            btnInfo.setOnAction(e -> Controllers.dialog(new ResourcePackInfoDialog(item)));

            if (booleanProperty != null) {
                checkBox.selectedProperty().unbindBidirectional(booleanProperty);
            }
            checkBox.selectedProperty().bindBidirectional(booleanProperty = item.enabledProperty());

            {
                var compatibility = file.getCompatibility();
                if (compatibility != ResourcePackFile.Compatibility.COMPATIBLE) {
                    pseudoClassStateChanged(WARNING, true);
                    content.addTagWarning(getWarning(compatibility));
                }
            }
        }
    }

    private static final class ResourcePackInfoDialog extends JFXDialogLayout {

        ResourcePackInfoDialog(ResourcePackInfoObject packInfoObject) {
            ResourcePackFile pack = packInfoObject.getFile();

            HBox titleContainer = new HBox();
            titleContainer.setSpacing(8);

            maxWidthProperty().bind(Controllers.getDecorator().contentWidthProperty().multiply(0.7));

            ImageContainer imageContainer = new ImageContainer(40);
            packInfoObject.iconCache.attachValue(imageContainer.imageProperty(), null);

            TwoLineListItem title = new TwoLineListItem();
            title.setTitle(pack.getFileName());
            title.setSubtitle(pack.getFileNameWithExtension());
            var compatibility = pack.getCompatibility();
            if (compatibility != ResourcePackFile.Compatibility.COMPATIBLE) {
                title.addTagWarning(getWarning(compatibility));
            }

            titleContainer.getChildren().setAll(imageContainer, title);
            setHeading(titleContainer);

            Label description = new Label(Objects.requireNonNullElse(pack.getDescription(), "").toString());
            description.setWrapText(true);
            FXUtils.copyOnDoubleClick(description);

            ScrollPane descriptionPane = new ScrollPane(description);
            FXUtils.smoothScrolling(descriptionPane);
            descriptionPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
            descriptionPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
            descriptionPane.setFitToWidth(true);
            FXUtils.onChange(description.heightProperty(), newVal -> {
                double maxHeight = Controllers.getDecorator().contentHeightProperty().get() * 0.5;
                double targetHeight = Math.min(newVal.doubleValue(), maxHeight);
                descriptionPane.setPrefViewportHeight(targetHeight);
            });

            setBody(descriptionPane);

            for (Pair<String, ? extends RemoteAddonRepository> item : Arrays.asList(
                    pair("addon.curseforge", CurseForgeRemoteAddonRepository.RESOURCE_PACKS),
                    pair("addon.modrinth", ModrinthRemoteAddonRepository.RESOURCE_PACKS)
            )) {
                RemoteAddonRepository repository = item.getValue();
                JFXHyperlink button = new JFXHyperlink(i18n(item.getKey()));
                Task.runAsync(() -> {
                    Optional<RemoteAddon.Version> versionOptional = repository.getRemoteVersionByLocalFile(packInfoObject.getFile().getFile());
                    if (versionOptional.isPresent()) {
                        RemoteAddon remoteAddon = repository.getAddonById(DownloadProviders.getDownloadProvider(), versionOptional.get().projectId());
                        FXUtils.runInFX(() -> {
                            button.setExternalLink(remoteAddon.pageUrl());
                            button.setDisable(false);
                        });
                    }
                }).start();
                button.setDisable(true);
                getActions().add(button);
            }

            JFXButton okButton = new JFXButton();
            okButton.getStyleClass().add("dialog-accept");
            okButton.setText(i18n("button.ok"));
            okButton.setOnAction(e -> fireEvent(new DialogCloseEvent()));
            getActions().add(okButton);

            onEscPressed(this, okButton::fire);
        }
    }
}
