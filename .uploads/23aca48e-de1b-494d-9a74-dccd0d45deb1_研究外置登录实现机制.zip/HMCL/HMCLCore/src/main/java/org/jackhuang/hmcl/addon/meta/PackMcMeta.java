/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2026 huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.addon.meta;

import com.google.gson.*;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import org.jackhuang.hmcl.addon.LocalAddonFile;
import org.jackhuang.hmcl.util.Pair;
import org.jackhuang.hmcl.util.StringUtils;
import org.jackhuang.hmcl.util.gson.JsonSerializable;
import org.jackhuang.hmcl.util.gson.JsonUtils;
import org.jackhuang.hmcl.util.gson.Validation;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.jackhuang.hmcl.util.logging.Logger.LOG;

@JsonSerializable
public record PackMcMeta(@SerializedName("pack") PackInfo pack) implements Validation {

    private static final Gson LENIENT_GSON = JsonUtils.defaultGsonBuilder().setStrictness(Strictness.LENIENT).create();

    public static PackMcMeta fromNonNullJson(String jsonString) throws JsonParseException {
        PackMcMeta parsed = LENIENT_GSON.fromJson(jsonString, PackMcMeta.class);
        if (parsed == null)
            throw new JsonParseException("Json object cannot be null.");
        return parsed;
    }

    public static PackMcMeta fromNonNullJsonFile(Path jsonFile) throws JsonParseException, IOException {
        try (var reader = Files.newBufferedReader(jsonFile)) {
            PackMcMeta parsed = LENIENT_GSON.fromJson(reader, PackMcMeta.class);
            if (parsed == null)
                throw new JsonParseException("Json object cannot be null.");
            return parsed;
        }
    }

    @Override
    public void validate() throws JsonParseException {
        if (pack == null)
            throw new JsonParseException("pack cannot be null");
    }

    @JsonAdapter(PackInfoDeserializer.class)
    public record PackInfo(@SerializedName("pack_format") int packFormat,
                           @SerializedName("supported_formats") SupportedFormats supportedFormats,
                           @SerializedName("min_format") PackVersion minPackVersion,
                           @SerializedName("max_format") PackVersion maxPackVersion,
                           @SerializedName("description") LocalAddonFile.Description description) {
        public PackVersion getEffectiveMinVersion() {
            return !minPackVersion.isUnspecified() ? minPackVersion : new PackVersion(packFormat, 0);
        }

        public PackVersion getEffectiveMaxVersion() {
            return !maxPackVersion.isUnspecified() ? maxPackVersion : new PackVersion(packFormat, 0);
        }
    }

    public record SupportedFormats(int min, int max) {

        public static final SupportedFormats UNSPECIFIED = new SupportedFormats(-1, -1);

        public static SupportedFormats fromJson(JsonElement element) {
            if (element == null || element.isJsonNull()) {
                return UNSPECIFIED;
            }

            try {
                if (element instanceof JsonArray jsonArray) {
                    if (jsonArray.size() == 2 && jsonArray.get(0).isJsonPrimitive() && jsonArray.get(1).isJsonPrimitive()) {
                        return new SupportedFormats(jsonArray.get(0).getAsInt(), jsonArray.get(1).getAsInt());
                    } else {
                        LOG.warning("Supported formats array must have 2 elements, but got " + jsonArray.size());
                    }
                } else if (element instanceof JsonObject jsonObj) {
                    if (jsonObj.get("min_inclusive").isJsonPrimitive() && jsonObj.get("max_inclusive").isJsonPrimitive()) {
                        return new SupportedFormats(jsonObj.get("min_inclusive").getAsInt(), jsonObj.get("max_inclusive").getAsInt());
                    } else {
                        LOG.warning("Supported formats object must have min_inclusive and max_inclusive properties, but got: " + jsonObj);
                    }
                }
            } catch (ClassCastException | NumberFormatException e) {
                LOG.warning("Failed to parse pack version component as a number. Value: " + element, e);
            }

            return UNSPECIFIED;
        }

        public boolean isUnspecified() {
            return getMin().isUnspecified() || getMax().isUnspecified() || getMin().compareTo(getMax()) > 0;
        }

        public PackVersion getMin() {
            return new PackVersion(min, 0);
        }

        public PackVersion getMax() {
            return new PackVersion(max, 0);
        }

    }

    public record PackVersion(int majorVersion, int minorVersion) implements Comparable<PackVersion> {

        public static final PackVersion UNSPECIFIED = new PackVersion(-1, -1);

        @Override
        public @NotNull String toString() {
            if (isUnspecified()) return "UNSPECIFIED";
            return minorVersion != 0 ? majorVersion + "." + minorVersion : String.valueOf(majorVersion);
        }

        @Override
        public int compareTo(PackVersion other) {
            boolean thisUnspecified = this.isUnspecified();
            boolean otherUnspecified = other.isUnspecified();
            if (thisUnspecified && otherUnspecified) return 0;
            if (thisUnspecified) return -1;
            if (otherUnspecified) return 1;
            int majorCompare = Integer.compare(this.majorVersion, other.majorVersion);
            if (majorCompare != 0) {
                return majorCompare;
            }
            return Integer.compare(this.minorVersion, other.minorVersion);
        }

        public boolean isUnspecified() {
            return this.majorVersion < 0 || this.minorVersion < 0;
        }

        public static PackVersion fromJson(JsonElement element, boolean anyMinor) throws JsonParseException {
            if (element == null || element.isJsonNull()) {
                return UNSPECIFIED;
            }

            try {
                if (element instanceof JsonPrimitive primitive && primitive.isNumber()) {
                    return new PackVersion(element.getAsInt(), anyMinor ? Integer.MAX_VALUE : 0);
                } else if (element instanceof JsonArray jsonArray) {
                    if (jsonArray.size() == 1 && jsonArray.get(0) instanceof JsonPrimitive) {
                        return new PackVersion(jsonArray.get(0).getAsInt(), anyMinor ? Integer.MAX_VALUE : 0);
                    } else if (jsonArray.size() == 2 && jsonArray.get(0) instanceof JsonPrimitive && jsonArray.get(1) instanceof JsonPrimitive) {
                        return new PackVersion(jsonArray.get(0).getAsInt(), jsonArray.get(1).getAsInt());
                    } else {
                        LOG.warning("Pack version array must have 1 or 2 elements, but got " + jsonArray.size());
                    }
                }
            } catch (NumberFormatException e) {
                LOG.warning("Failed to parse pack version component as a number. Value: " + element, e);
            }

            return UNSPECIFIED;
        }
    }

    public static final class PackInfoDeserializer implements JsonDeserializer<PackInfo> {

        private List<LocalAddonFile.Description.Part> pairToPart(List<Pair<String, String>> lists, String color) {
            List<LocalAddonFile.Description.Part> parts = new ArrayList<>();
            for (Pair<String, String> list : lists) {
                parts.add(new LocalAddonFile.Description.Part(list.getKey(), list.getValue().isEmpty() ? color : list.getValue()));
            }
            return parts;
        }

        private void parseComponent(JsonElement element, List<LocalAddonFile.Description.Part> parts, String parentColor) throws JsonParseException {
            if (parentColor == null) {
                parentColor = "";
            }
            String color = parentColor;
            if (element instanceof JsonPrimitive primitive) {
                parts.addAll(pairToPart(StringUtils.parseMinecraftColorCodes(primitive.getAsString()), color));
            } else if (element instanceof JsonObject jsonObj) {
                if (jsonObj.get("color") instanceof JsonPrimitive primitive) {
                    color = primitive.getAsString();
                }
                if (jsonObj.get("text") instanceof JsonPrimitive primitive) {
                    parts.addAll(pairToPart(StringUtils.parseMinecraftColorCodes(primitive.getAsString()), color));
                }
                if (jsonObj.get("extra") instanceof JsonArray jsonArray) {
                    parseComponent(jsonArray, parts, color);
                }
            } else if (element instanceof JsonArray jsonArray) {
                if (!jsonArray.isEmpty() && jsonArray.get(0) instanceof JsonObject jsonObj && jsonObj.get("color") instanceof JsonPrimitive primitive) {
                    color = primitive.getAsString();
                }

                for (JsonElement childElement : jsonArray) {
                    parseComponent(childElement, parts, color);
                }
            } else {
                LOG.warning("Skipping unsupported element in description. Expected a string, object, or array, but got type " + element.getClass().getSimpleName() + ". Value: " + element);
            }
        }

        private List<LocalAddonFile.Description.Part> parseDescription(JsonElement json) throws JsonParseException {
            List<LocalAddonFile.Description.Part> parts = new ArrayList<>();

            if (json == null || json.isJsonNull()) {
                return parts;
            }

            try {
                parseComponent(json, parts, "");
            } catch (JsonParseException | IllegalStateException e) {
                parts.clear();
                LOG.warning("An unexpected error occurred while parsing a description component. The description may be incomplete.", e);
            }

            return parts;
        }

        @Override
        public PackInfo deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            JsonObject packInfo = json.getAsJsonObject();
            int packFormat;
            if (packInfo.get("pack_format") instanceof JsonPrimitive primitive && primitive.isNumber()) {
                packFormat = primitive.getAsInt();
            } else {
                packFormat = 0;
            }
            SupportedFormats supportedFormats = SupportedFormats.fromJson(packInfo.get("supported_formats"));
            PackVersion minVersion = PackVersion.fromJson(packInfo.get("min_format"), false);
            PackVersion maxVersion = PackVersion.fromJson(packInfo.get("max_format"), true);

            List<LocalAddonFile.Description.Part> parts = parseDescription(packInfo.get("description"));
            return new PackInfo(packFormat, supportedFormats, minVersion, maxVersion, new LocalAddonFile.Description(parts));
        }
    }

}
