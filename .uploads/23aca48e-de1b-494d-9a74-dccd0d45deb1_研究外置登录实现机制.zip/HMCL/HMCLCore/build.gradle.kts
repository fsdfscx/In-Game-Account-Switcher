plugins {
    `java-library`
}

tasks.withType<JavaCompile> {
    sourceCompatibility = "17"
    targetCompatibility = "17"
}

tasks.compileJava {
    options.compilerArgs.add("--add-exports=jdk.attach/sun.tools.attach=ALL-UNNAMED")
}

dependencies {
    api(libs.kala.compress.zip)
    api(libs.kala.compress.tar)
    api(libs.kala.encoding.detctor)
    api(libs.simple.png.javafx)
    api(libs.gson)
    api(libs.tomlj)
    api(libs.xz)
    api(libs.lz4)
    api(libs.fx.gson)
    api(libs.constant.pool.scanner)
    api(libs.nanohttpd)
    api(libs.jsoup)
    api(libs.jna)
    api(libs.pci.ids)
    api(libs.hello.nbt)
    api(libs.weburl)
    api(libs.uuid.tools)
    api(libs.commonmark)
    api(libs.commonmark.autolink)
    api(libs.commonmark.underline)
    api(libs.commonmark.strikethrough)
    api(libs.commonmark.table)

    compileOnlyApi(libs.jetbrains.annotations)

    testImplementation(libs.jna.platform)
    testImplementation(libs.jimfs)
}

tasks.processResources {
    listOf(
        "HMCLTransformerDiscoveryService",
        "HMCLMultiMCBootstrap"
    ).map { project(":$it").tasks["jar"] as Jar }.forEach { task ->
        dependsOn(task)

        into("assets/game") {
            from(task.outputs.files)
        }
    }
}

tasks.register("updateLiteLoaderVersionList", org.jackhuang.hmcl.gradle.component.UpdateLiteLoaderVersionList::class) {
    description = "Update LiteLoader version list"

    outputFile.set(projectDir.resolve("src/main/resources/assets/liteloader/versions.json"))
}
